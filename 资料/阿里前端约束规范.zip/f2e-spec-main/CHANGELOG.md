# 更新日志

## 1.0.0 (2022-03-17)

### 新增

- 开放 10 篇规约文档，包括：
  * 7 篇编码规约：HTML 编码规约、CSS 编码规约、JavaScript 编码规约、React 编码规约、Node.js 开发规约、TypeScript 编码规约、Rax 编码规约
  * 3 篇工程规约：Git 规约、文档通用规约、更新日志规约

## 0.1.0 (2020-12-03)

### 新增

- 开放五个规约配套 npm 包源码，包括：f2elint、eslint-config-ali、stylelint-config-ali、commitlint-config-ali、markdownlint-config-ali
