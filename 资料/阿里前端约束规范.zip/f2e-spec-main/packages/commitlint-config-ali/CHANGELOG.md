# 更新日志

## 1.1.0 - 2024-04-08

- 升级 conventional-changelog-conventionalcommits 4.x 到 7.x

## 1.0.0 (2023-12-18)

- 稳定版

## 0.1.3 (2020-12-03)

### 优化

- 修改 package.json 和 README

## 0.1.2 (2020-11-25)

### 变更

- type-enum 规则：移除 Git 规约中未提及的 type，并修改 type 顺序

## 0.1.1 (2020-11-13)

### 修复

- conventional-changelog-conventionalcommits 版本升级到 ^4.5.0

## 0.1.0 (2020-04-30)

### 新增

- Fork from [@commitlint/config-conventional](https://github.com/conventional-changelog/commitlint/tree/master/%40commitlint/config-conventional)，并关闭 subject-case
