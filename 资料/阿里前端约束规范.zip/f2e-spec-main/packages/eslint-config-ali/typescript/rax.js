module.exports = {
  extends: ['../rax', '../rules/typescript'].map(require.resolve),
};
