module.exports = {
  extends: ['./node', '../rules/egg'].map(require.resolve),
};
