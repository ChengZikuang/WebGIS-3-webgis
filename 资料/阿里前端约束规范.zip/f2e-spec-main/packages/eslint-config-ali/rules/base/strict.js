module.exports = {
  rules: {
    // 不限制严格模式的使用
    strict: 'off',
  },
};
