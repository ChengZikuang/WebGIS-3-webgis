module.exports = {
  extends: ['./rules/jsx-a11y'].map(require.resolve),
};
