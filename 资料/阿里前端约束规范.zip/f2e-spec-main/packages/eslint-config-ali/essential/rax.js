module.exports = {
  extends: ['./react', '../rax'].map(require.resolve),
};
