let foo = [1,2]
console.log(foo);
eval('alert(1)');
