import { b } from '@/ts-import-b';

export const a = b;
