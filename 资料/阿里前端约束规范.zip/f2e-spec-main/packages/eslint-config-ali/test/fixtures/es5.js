var hero = {
  firstName: 'Kevin',
  lastName: 'Flynn',
};
