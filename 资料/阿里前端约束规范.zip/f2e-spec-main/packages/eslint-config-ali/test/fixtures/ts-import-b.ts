import { a } from '@/ts-import-c';

export const b = a;
