import React from 'react';

export default () => {
  return (
    <p>hello, world</p>
  )
}
