import { Options } from 'prettier';

const config: Options;

export default config;
