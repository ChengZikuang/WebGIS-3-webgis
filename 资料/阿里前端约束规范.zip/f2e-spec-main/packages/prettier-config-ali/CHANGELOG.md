# 更新日志

## 1.3.0 - 2024-04-07

- 更改为 ESM 包

## 1.2.0 - 2024-04-07

- 重新添加 `prettier-plugin-packagejson`
- 补全 Prettier 选项

## 1.1.0 - 2024-01-23

- 移除 `prettier-plugin-packagejson` (在 `type: module` 项目中报错)

## 1.0.0 (2023-12-18)

- 初始版本
