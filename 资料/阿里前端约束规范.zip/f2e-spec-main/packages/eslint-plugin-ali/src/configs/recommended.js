module.exports = {
  plugins: ['ali'],
  rules: {
    'ali/no-http-url': 'warn',
    'ali/no-secret-info': 'error',
  },
};
