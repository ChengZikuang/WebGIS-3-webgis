# 更新日志

## 1.0.1 (2021-09-15)

### 优化
- 统一文件命名

## 1.0.0 (2020-12-15)

### 新增
- 新增规则：
  - `no-broad-semantic-versioning`
  - `no-http-url`
  - `no-js-in-ts-project`
  - `no-secret-info`