export enum TemplateType {
  BaseJS = 'base-js',
  BaseTS = 'base-ts',
  EggJS = 'egg-js',
  EggTS = 'egg-ts',
  NodeJS = 'node-js',
  NodeTS = 'node-ts',
  ReactJS = 'react-js',
  ReactTS = 'react-ts',
  VueJS = 'vue-js',
  VueTS = 'vue-ts',
}
