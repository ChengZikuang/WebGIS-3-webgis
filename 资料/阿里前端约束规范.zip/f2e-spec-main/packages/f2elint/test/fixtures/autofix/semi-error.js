const hello = (name) => {
  return `hello, ${name}`;
};

hello('world');
