/*
 * 小程序使用的非标准选择器
 */

module.exports = [
  'page',
  'swiper',
  'icon',
  'radio',
  'checkbox',
  'slider',
  'picker',
  'navigator',
  'lifestyle',
];
